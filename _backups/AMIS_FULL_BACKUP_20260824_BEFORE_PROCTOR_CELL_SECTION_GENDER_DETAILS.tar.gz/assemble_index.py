#!/usr/bin/env python3
"""
assemble_index.py
Builds the clean, professional home gateway for AMIS Schedule Management System.
"""

import json
import os

BASE_DIR = "/home/tatsuya/Projects/AMIS/amis_exam_calendar"

with open(os.path.join(BASE_DIR, "teacher_weekly_schedules.json"), "r", encoding="utf-8") as f:
    teacher_data = json.load(f)

with open(os.path.join(BASE_DIR, "exam_data.json"), "r", encoding="utf-8") as f:
    exam_data = json.load(f)

with open(os.path.join(BASE_DIR, "class_schedules_data.json"), "r", encoding="utf-8") as f:
    class_data = json.load(f)

total_sections = len(class_data)
total_exam_sessions = len(exam_data)
active_faculty_count = len([t for t in teacher_data.values() if t.get('total_classes', 0) > 0])

html_content = f'''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AL MUNAWWARA ISLAMIC SCHOOL — Schedule Management System</title>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  
  <style>
    :root {{
      --brand-primary: #064e3b;
      --brand-primary-hover: #043d2e;
      --brand-accent: #0f766e;
      --brand-surface: #f0fdf4;
      --brand-border: #a7f3d0;
      
      --exam-primary: #1e3a8a;
      --exam-primary-hover: #172554;
      --exam-accent: #2563eb;
      --exam-surface: #eff6ff;
      --exam-border: #bfdbfe;
      
      --bg: #f8fafc;
      --surface: #ffffff;
      --text: #0f172a;
      --text-secondary: #334155;
      --text-muted: #64748b;
      --line: #e2e8f0;
      --line-strong: #cbd5e1;
      
      --radius-sm: 8px;
      --radius-md: 12px;
      --radius-lg: 16px;
      --radius-xl: 20px;
      
      --shadow-card: 0 4px 20px rgba(15, 23, 42, 0.06);
      --shadow-hover: 0 16px 36px -4px rgba(15, 23, 42, 0.12);
      --transition: all 250ms cubic-bezier(0.16, 1, 0.3, 1);
    }}

    * {{
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }}

    body {{
      font-family: 'Plus Jakarta Sans', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background-color: var(--bg);
      color: var(--text);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }}

    .top-bar {{
      height: 4px;
      background: linear-gradient(90deg, #064e3b 0%, #0f766e 50%, #2563eb 100%);
      width: 100%;
    }}

    .main-wrapper {{
      max-width: 1020px;
      width: 100%;
      margin: 0 auto;
      padding: 40px 24px 32px 24px;
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }}

    /* Header */
    .hero-header {{
      text-align: center;
      margin-bottom: 24px;
      display: flex;
      flex-direction: column;
      align-items: center;
    }}

    .logo-container {{
      position: relative;
      margin-bottom: 16px;
      display: inline-block;
    }}

    .school-official-logo {{
      width: 96px;
      height: 96px;
      border-radius: 50%;
      object-fit: contain;
      filter: drop-shadow(0 6px 16px rgba(6, 78, 59, 0.2));
      transition: var(--transition);
      background: #ffffff;
      padding: 2px;
    }}

    .school-official-logo:hover {{
      transform: scale(1.04) rotate(2deg);
    }}

    .school-name {{
      font-size: 24px;
      font-weight: 900;
      letter-spacing: 0.04em;
      color: var(--brand-primary);
      text-transform: uppercase;
      line-height: 1.2;
      margin-bottom: 6px;
    }}

    .system-title {{
      font-size: 16px;
      font-weight: 800;
      color: var(--text-secondary);
      letter-spacing: 0.01em;
      margin-bottom: 8px;
    }}

    .system-desc {{
      font-size: 13.5px;
      color: var(--text-muted);
      font-weight: 500;
      max-width: 500px;
      line-height: 1.5;
      margin-bottom: 14px;
    }}

    /* System Integrity & Anti-Conflict Banner */
    .integrity-banner {{
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 12px;
      width: 100%;
      margin-bottom: 28px;
    }}

    .integrity-pill {{
      background: #ffffff;
      border: 1.5px solid #a7f3d0;
      padding: 10px 14px;
      border-radius: var(--radius-md);
      display: flex;
      align-items: center;
      gap: 10px;
      box-shadow: 0 2px 10px rgba(6, 78, 59, 0.04);
    }}

    .pill-icon {{
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: #dcfce7;
      color: #059669;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
      font-weight: 900;
      flex-shrink: 0;
    }}

    .pill-content h4 {{
      font-size: 10.5px;
      font-weight: 700;
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }}

    .pill-content p {{
      font-size: 13.5px;
      font-weight: 800;
      color: var(--brand-primary);
    }}

    /* Cards Grid */
    .cards-container {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 24px;
      width: 100%;
      margin-bottom: 20px;
    }}

    .card {{
      background: var(--surface);
      border: 1.5px solid var(--line);
      border-radius: var(--radius-xl);
      padding: 28px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      box-shadow: var(--shadow-card);
      transition: var(--transition);
      cursor: pointer;
    }}

    .card:hover {{
      transform: translateY(-4px);
      box-shadow: var(--shadow-hover);
    }}

    .card-class {{
      border-top: 4px solid var(--brand-accent);
    }}

    .card-class:hover {{
      border-color: #5eead4;
      border-top-color: var(--brand-accent);
    }}

    .card-exam {{
      border-top: 4px solid var(--exam-accent);
    }}

    .card-exam:hover {{
      border-color: #93c5fd;
      border-top-color: var(--exam-accent);
    }}

    .card-body {{
      margin-bottom: 24px;
    }}

    .card-icon {{
      width: 50px;
      height: 50px;
      border-radius: var(--radius-md);
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 16px;
      transition: var(--transition);
    }}

    .card-class .card-icon {{
      background: var(--brand-surface);
      color: var(--brand-primary);
      border: 1px solid var(--brand-border);
    }}

    .card-exam .card-icon {{
      background: var(--exam-surface);
      color: var(--exam-primary);
      border: 1px solid var(--exam-border);
    }}

    .card-icon svg {{
      width: 26px;
      height: 26px;
      stroke-width: 2;
    }}

    .card-heading {{
      font-size: 19px;
      font-weight: 800;
      color: var(--text);
      margin-bottom: 8px;
      letter-spacing: -0.01em;
    }}

    .card-text {{
      font-size: 13.5px;
      color: var(--text-secondary);
      line-height: 1.55;
      margin-bottom: 18px;
    }}

    .feature-list {{
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }}

    .feature-list li {{
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12.5px;
      font-weight: 600;
      color: var(--text-secondary);
    }}

    .feature-list li svg {{
      width: 15px;
      height: 15px;
      flex-shrink: 0;
    }}

    .card-class .feature-list li svg {{
      color: #059669;
    }}

    .card-exam .feature-list li svg {{
      color: #2563eb;
    }}

    .card-footer {{
      display: flex;
      flex-direction: column;
      gap: 14px;
    }}

    .btn-main {{
      width: 100%;
      padding: 12px 18px;
      border-radius: var(--radius-sm);
      font-size: 14px;
      font-weight: 800;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      text-decoration: none;
      transition: var(--transition);
      border: none;
    }}

    .btn-class {{
      background: var(--brand-primary);
      color: #ffffff;
    }}

    .btn-class:hover {{
      background: var(--brand-primary-hover);
      box-shadow: 0 4px 14px rgba(6, 78, 59, 0.3);
    }}

    .btn-exam {{
      background: var(--exam-primary);
      color: #ffffff;
    }}

    .btn-exam:hover {{
      background: var(--exam-primary-hover);
      box-shadow: 0 4px 14px rgba(30, 58, 138, 0.3);
    }}

    .btn-main svg {{
      width: 16px;
      height: 16px;
      stroke-width: 2.5;
      transition: transform 200ms ease;
    }}

    .card:hover .btn-main svg {{
      transform: translateX(4px);
    }}

    /* Developer Credit below buttons (Text Only) */
    .developer-bottom-text {{
      margin-top: 32px;
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
    }}

    .developer-bottom-text .dev-label {{
      font-size: 14px;
      font-weight: 700;
      color: var(--text-secondary);
      letter-spacing: 0.01em;
    }}

    .developer-bottom-text .dev-name {{
      font-size: 20px;
      font-weight: 900;
      color: var(--brand-primary);
      letter-spacing: -0.01em;
    }}

    /* Footer */
    .site-footer {{
      text-align: center;
      padding: 20px 24px;
      border-top: 1px solid var(--line);
      background: var(--surface);
      font-size: 12.5px;
      font-weight: 600;
      color: var(--text-muted);
    }}

    @media (max-width: 768px) {{
      .integrity-banner {{
        grid-template-columns: 1fr 1fr;
      }}
      .cards-container {{
        grid-template-columns: 1fr;
        gap: 18px;
      }}
      .main-wrapper {{
        padding: 28px 16px;
      }}
    }}
  </style>
</head>
<body>

  <div class="top-bar"></div>

  <main class="main-wrapper">

    <!-- Header & Branding -->
    <header class="hero-header">
      <div class="logo-container">
        <img src="amis_logo.png" alt="Al Munawwara Islamic School Official Seal" class="school-official-logo">
      </div>

      <h1 class="school-name">AL MUNAWWARA ISLAMIC SCHOOL</h1>
      <h2 class="system-title">Schedule Management System</h2>
      <p class="system-desc">Manage and view official class schedules, examination schedules, and faculty timetables.</p>
    </header>

    <!-- Real-Time Anti-Conflict & Duplicate Guard Banner -->
    <section class="integrity-banner">
      <div class="integrity-pill">
        <div class="pill-icon">✓</div>
        <div class="pill-content">
          <h4>Anti-Conflict Guard</h4>
          <p>0 Conflicts Detected</p>
        </div>
      </div>
      <div class="integrity-pill">
        <div class="pill-icon">✓</div>
        <div class="pill-content">
          <h4>Duplicate Guard</h4>
          <p>0 Duplicate Slots</p>
        </div>
      </div>
      <div class="integrity-pill">
        <div class="pill-icon">✓</div>
        <div class="pill-content">
          <h4>Active Sections</h4>
          <p>{total_sections} Sections Live</p>
        </div>
      </div>
      <div class="integrity-pill">
        <div class="pill-icon">✓</div>
        <div class="pill-content">
          <h4>Verified Faculty</h4>
          <p>{active_faculty_count} Members with Load</p>
        </div>
      </div>
    </section>

    <!-- Balanced Two Cards Grid -->
    <div class="cards-container">

      <!-- Card 1: Official Class Schedule -->
      <div class="card card-class" onclick="window.location.href='class-schedule.html'">
        <div class="card-body">
          <div class="card-icon" aria-hidden="true">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
              <line x1="16" y1="2" x2="16" y2="6"/>
              <line x1="8" y1="2" x2="8" y2="6"/>
              <line x1="3" y1="10" x2="21" y2="10"/>
              <path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01M16 18h.01"/>
            </svg>
          </div>

          <h3 class="card-heading">Official Class Schedule</h3>
          <p class="card-text">View and manage the official class schedules for all departments, grades, sections, shifts, and faculty.</p>

          <ul class="feature-list">
            <li>
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
              <span>{total_sections} Active Sections across Kinder, Elementary, JHS & SHS</span>
            </li>
            <li>
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
              <span>Face-to-Face, ODL 1st Shift & ODL 2nd Shift Timetables</span>
            </li>
            <li>
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
              <span>Clean 5-Day Merged Span Timetable Layout</span>
            </li>
          </ul>
        </div>

        <div class="card-footer">
          <a href="class-schedule.html" class="btn-main btn-class">
            <span>View Class Schedule</span>
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
              <line x1="5" y1="12" x2="19" y2="12"/>
              <polyline points="12 5 19 12 12 19"/>
            </svg>
          </a>
        </div>
      </div>

      <!-- Card 2: Exam Schedule -->
      <div class="card card-exam" onclick="window.location.href='exam-schedule.html'">
        <div class="card-body">
          <div class="card-icon" aria-hidden="true">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
              <polyline points="14 2 14 8 20 8"/>
              <line x1="16" y1="13" x2="8" y2="13"/>
              <line x1="16" y1="17" x2="8" y2="17"/>
              <polyline points="10 9 9 9 8 9"/>
            </svg>
          </div>

          <h3 class="card-heading">Term Exam Week</h3>
          <p class="card-text">Official 4-day term examination schedule, faculty timetables, and subject verification roster.</p>

          <ul class="feature-list">
            <li>
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
              <span>{total_exam_sessions} Curricular Exam Sessions (Zero Conflicts)</span>
            </li>
            <li>
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
              <span>Standard S.Y. 2025–2026 Reference Time Allocations</span>
            </li>
            <li>
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
              <span>Faculty Roster &amp; Assigned Subject Verification Tabs</span>
            </li>
          </ul>
        </div>

        <div class="card-footer">
          <a href="exam-schedule.html" class="btn-main btn-exam">
            <span>View Exam Schedule</span>
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
              <line x1="5" y1="12" x2="19" y2="12"/>
              <polyline points="12 5 19 12 12 19"/>
            </svg>
          </a>
        </div>
      </div>

    </div>

    <!-- Developer Credit below the 2 buttons (Text Only) -->
    <div class="developer-bottom-text">
      <span class="dev-label">Developed by:</span>
      <span class="dev-name">Software Engineer Mon Zhairel Lingasa</span>
    </div>

  </main>

  <footer class="site-footer">
    AL MUNAWWARA ISLAMIC SCHOOL • Academic Year 2026–2027
  </footer>

</body>
</html>
'''

with open(os.path.join(BASE_DIR, "index.html"), "w", encoding="utf-8") as f:
    f.write(html_content)

print(f"✓ Built clean index.html!")
